# AngularHttp

maiores detalhes: [Consumindo API REST com HttpClient no Angular 8]

Versão:  [Angular CLI](https://github.com/angular/angular-cli) version 8.3.5.

## subir servidor de desenvolvimento

Após o `ng serve`, navegue até `http://localhost:4200/`.


## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## testes unitarios

rode `ng test` e execute os testes via [Karma](https://karma-runner.github.io).

## testes de integração

rode `ng e2e` e execute os testes de ponta a ponta [Protractor](http://www.protractortest.org/).


