export interface Car {
    id: number;
    model: string;
    color: string;
    price: number;

}
